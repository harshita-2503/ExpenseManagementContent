import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-I5CODIM5.js";
import "./chunk-WQBQHXNS.js";
import "./chunk-MGN7E3DQ.js";
import "./chunk-EBY6SNMV.js";
import "./chunk-VZQ3STSP.js";
import "./chunk-IYEYSCYL.js";
import "./chunk-V2W2CMHM.js";
import "./chunk-NEKU525M.js";
import "./chunk-35ENWJA4.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
//# sourceMappingURL=@angular_fire_compat.js.map
