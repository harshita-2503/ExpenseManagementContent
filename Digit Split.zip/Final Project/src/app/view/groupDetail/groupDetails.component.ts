import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GroupRepositroy } from '../../model/group.repository';
import { Group } from '../../model/group.model';
import { User } from '../../model/user.model';
import { Expense } from '../../model/expense.model';
import { UserService } from '../../services/user.service';
import { GroupDataService } from '../../services/groupdata.service';
import { Router } from '@angular/router';

@Component({
  selector: 'group-details',
  templateUrl: 'groupDetails.component.html',
  styleUrls: ['groupDetails.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GroupDetailComponent implements OnInit {
  enableGroupDetail = true;
  group?: Group;
  groupId?: string;
  groupMembers: User[] = [];
  balances: { [userId: string]: number } = {};
  currentUserId: string = '';
  groupMembersData?: User[] = [];
  groupCreatorId?: string = '';
  enableDelete: boolean = false;

  constructor(
    private groupRepo: GroupRepositroy,
    private activeRoute: ActivatedRoute,
    private userService: UserService,
    private groupService: GroupDataService,
    private cdr: ChangeDetectorRef,
    private router: Router
  ) {
    this.groupId = this.groupService.getGroupId();
    this.currentUserId = this.userService.getUserId();
  }

  ngOnInit(): void {
    this.group = this.groupRepo.getGroup(this.groupId);
    this.groupCreatorId = this.group?.created_by;
    this.enableDelete = this.currentUserId === this.groupCreatorId;

    if (this.group?.members) {
      this.groupMembers = this.groupRepo.getGroupUsersData(this.groupId);
      this.groupMembers.forEach((m) => (this.balances[m.user_id!] = 0));

      this.groupRepo
        .getExpenses$(this.groupId)
        .subscribe((expenses: Expense[]) => {
          this.calculateBalances(expenses);
          this.cdr.markForCheck();
        });
    }
  }

  //  onExpenseAdded(expense: Expense): void {
  //  this.groupRepo
  //  .getExpenses$(this.groupId)
  //  .subscribe((expenses: Expense[]) => {
  //  this.calculateBalances(expenses);
  //  this.cdr.markForCheck();
  //  });
  //  }

  private calculateBalances(expenses: Expense[]) {
    Object.keys(this.balances).forEach((id) => (this.balances[id] = 0));

    expenses.forEach((exp) => {
      const amount = Number(exp.amount) || 0;
      const participants = exp.users ?? [];
      if (amount <= 0 || participants.length === 0) return;

      const share = amount / participants.length;

      participants.forEach((u) => {
        if (this.balances[u] === undefined) this.balances[u] = 0;
        this.balances[u] -= share;
      });

      if (exp.paid_by) {
        if (this.balances[exp.paid_by] === undefined)
          this.balances[exp.paid_by] = 0;
        this.balances[exp.paid_by] += amount;
      }
    });

    Object.keys(this.balances).forEach(
      (id) => (this.balances[id] = Math.round(this.balances[id] * 100) / 100)
    );
  }

  get getGroupUsersData(): User[] {
    this.groupMembersData = this.groupRepo.getGroupUsersData(this.groupId);
    return this.groupMembersData;
  }

  get otherMembers(): User[] {
    return this.groupMembers.filter((m) => m.user_id !== this.currentUserId);
  }
  deleteGroupByUser(): void {
    this.groupRepo.deleteGroup(this.group ?? {});
    this.router.navigateByUrl('/show-groups');
  }
}
