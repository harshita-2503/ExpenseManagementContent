import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/authService';
import { UserService } from '../services/user.service';
import {
  FormBuilder,
  FormControl,
  Validators,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { noSpecialChars } from '../validators/no-special-chars.validators';
import Typed from 'typed.js';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './login.component.html',
  standalone: true,
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
})
export class LoginComponent implements AfterViewInit {
  @ViewChild('textElement', { static: false }) textElement!: ElementRef;

  currentUserId: string | null = '';
  currentUserName: string | null = '';
  loginAs: string = 'user';
  submittedForm: boolean = false;
  errorMessage: string = '';
  authenticationData: any;

  constructor(
    private auth: AuthService,
    private router: Router,
    private userDetails: UserService,
    private fb: FormBuilder
  ) {
    this.authenticationData = this.fb.group({
      user_name: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(100),
        noSpecialChars,
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(16),
      ]),
    });
  }

  ngAfterViewInit(): void {
    const typedOptions1 = {
      strings: [
        'Create Group',
        'Add Expense',
        'Add Members',
        'Managing Expenses',
      ],
      typeSpeed: 100,
      backSpeed: 100,
      backDelay: 1000,
      loop: true,
    };

    new Typed(this.textElement.nativeElement, typedOptions1);
  }

  signInWithGoogle() {
    this.auth
      .googleSignIn()
      .then((res) => {
        console.log('Logged in:', res.user?.displayName);
        this.router.navigateByUrl('/group');
      })
      .catch((err) => console.error('Login error:', err));
  }

  setUser(userId: string) {
    this.userDetails.setUser(userId, this.auth.getDisplayName());
    console.log(
      this.userDetails.getUserId() + ' ' + this.userDetails.getUserName()
    );
    this.router.navigateByUrl('/show-groups');
  }

  changeCurrentLogin(role: string): void {
    this.loginAs = role;
    this.submitForm();
  }

  submitForm() {
    this.submittedForm = true;
    if (this.authenticationData.valid) {
      this.auth
        .authenticate(
          this.authenticationData.value.user_name ?? '',
          this.authenticationData.value.password ?? '',
          this.loginAs ?? ''
        )
        .subscribe((response) => {
          if (response) {
            this.currentUserId = localStorage.getItem('user_id');
            this.currentUserName = this.authenticationData.value.user_name;
            try {
              if (this.currentUserId != null && this.loginAs == 'user') {
                this.userDetails.setUser(
                  this.currentUserId,
                  this.currentUserName
                );
                setTimeout(() => {
                  this.router.navigateByUrl('/show-groups');
                }, 0);
              } else if (this.loginAs == 'admin') {
                this.router.navigateByUrl('/admin/show-all-groups');
              } else {
                this.router.navigateByUrl('/');
              }
            } catch (error: any) {
              this.errorMessage = error.message;
              this.router.navigateByUrl('/');
            }
          }
        });
    } else {
      console.log('Form not valid');
    }
  }
}
