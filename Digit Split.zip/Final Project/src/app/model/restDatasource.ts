import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, Observable, switchAll, throwError } from 'rxjs';
import { User } from './user.model';
import { Group } from './group.model';

const PROTOCOL = 'http';
const PORT = 3500;

@Injectable()
export class RestDataSource {
  private baseUrl: string;
  auth_token?: string;

  constructor(private http: HttpClient) {
    // this.baseUrl = `${PROTOCOL}://${location.hostname}:${PORT}/`;
    this.baseUrl = '/api/';
  }

  getUsers(): Observable<User[]> {
    return this.http.get<any[]>(this.baseUrl + 'user').pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  getUser(id: string): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}user?user_id=${id}`).pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  addUser(user: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + 'user', user).pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  updateUser(userId: any, updatedUser: any) {
    console.log('PUT request to:', `http://localhost:3500/user/${userId}}`);
    return this.http
      .put(`${this.baseUrl}user/${userId}`, updatedUser)
      .toPromise();
  }

  deleteUser(id: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}user/${id}`).pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  getGroups(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + 'groups').pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  getGroupById(id: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}groups/${id}`).pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  addGroup(group: Group): Observable<any> {
    return this.http.post<any>(this.baseUrl + 'groups', group).pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  updateGroup(groupId: string, updatedGroup: any): Observable<any> {
    console.log('PUT request to:', `http://localhost:3500/groups/${groupId}`);

    return this.http
      .put<any>(`${this.baseUrl}groups/${groupId}`, updatedGroup)
      .pipe(
        catchError((err) => {
          console.log('Error caught on service level');
          console.log('error message:' + err.message);
          return throwError(err);
        })
      );
  }

  deleteGroup(id: any): Observable<any> {
    return this.http
      .delete<any>(`${this.baseUrl}groups/${id}`, this.getOptions())
      .pipe(
        catchError((err) => {
          console.log('Error caught on service level');
          console.log('error message:' + err.message);
          return throwError(err);
        })
      );
  }

  getExpenses(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + 'expenses').pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  getExpensesByGroup(groupId: number): Observable<any[]> {
    return this.http
      .get<any[]>(`${this.baseUrl}expenses?group_id=${groupId}`)
      .pipe(
        catchError((err) => {
          console.log('Error caught on service level');
          console.log('error message:' + err.message);
          return throwError(err);
        })
      );
  }

  addExpense(expense: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + 'expenses', expense).pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  updateExpense(expense: any): Observable<any> {
    return this.http
      .put<any>(`${this.baseUrl}expenses/${expense.expense_id}`, expense)
      .pipe(
        catchError((err) => {
          console.log('Error caught on service level');
          console.log('error message:' + err.message);
          return throwError(err);
        })
      );
  }

  deleteExpense(id: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}expenses/${id}`).pipe(
      catchError((err) => {
        console.log('Error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  getGroupsByUserId(userId: string): Observable<string[]> {
    return this.http.get<any[]>(`${this.baseUrl}user`).pipe(
      map((users) => {
        const user = users.find((u) => u.user_id === userId);
        return user?.userGroups ?? [];
      }),
      catchError((err) => {
        console.log('error caught on service level');
        console.log('error message:' + err.message);
        return throwError(err);
      })
    );
  }

  updateUserByUserId(user: User): Observable<any> {
    return this.http
      .get<User[]>(`${this.baseUrl}user?user_id=${user.user_id}`)
      .pipe(
        map((users) => {
          if (!users || users.length === 0) {
            throw new Error('User not found');
          }

          const existingUser = users[0];
          const internalId = existingUser.id;

          if (!internalId) {
            throw new Error('User is missing internal id');
          }

          return this.http.put(`${this.baseUrl}user/${internalId}`, user);
        }),
        switchAll(),
        catchError((err) => {
          console.log('error caught on service level');
          console.log('error message:' + err.message);
          return throwError(err);
        })
      );
  }

  authenticate(user: string, pass: string): Observable<boolean> {
    return this.http
      .post<any>(this.baseUrl + 'login', {
        name: user,
        password: pass,
        role: 'user',
      })
      .pipe(
        map((response) => {
          this.auth_token = response.success ? response.token : null;
          console.log(response);
          localStorage.setItem('user_token', response.token);
          localStorage.setItem('user_name', user);
          localStorage.setItem('refresh_token', response.refresh_token);
          localStorage.setItem('user_id', response.id);

          return response.success;
        }),
        catchError((err) => {
          console.log('error caught on service level');
          console.log('error message:' + err.message);
          return throwError(err);
        })
      );
  }

  authenticateAdmin(user: string, pass: string): Observable<boolean> {
    return this.http
      .post<any>(this.baseUrl + 'login', {
        name: user,
        password: pass,
        role: 'admin',
      })
      .pipe(
        map((response) => {
          this.auth_token = response.success ? response.token : null;
          console.log(response);
          localStorage.setItem('admin_token', response.token);
          localStorage.setItem('admin_name', user);
          localStorage.setItem('refresh_token', response.refresh_token);
          return response.success;
        }),
        catchError((err) => {
          console.log('error caught on service level');
          console.log('error message:' + err.message);
          return throwError(err);
        })
      );
  }

  deleteGroupByAdmin(id: any): Observable<any> {
    return this.http
      .delete<any>(`${this.baseUrl}groups/${id}`, this.getOptions())
      .pipe(
        catchError((err) => {
          console.log('Error caught on service level');
          console.log('error message:' + err.message);
          return throwError(err);
        })
      );
  }

  private getOptions() {
    return {
      headers: new HttpHeaders({
        Authorization: `Bearer<${localStorage.getItem('admin_token')}>`,
      }),
    };
  }
}
