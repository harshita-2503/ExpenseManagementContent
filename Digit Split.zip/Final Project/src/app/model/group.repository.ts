import { Injectable } from '@angular/core';
import { RestDataSource } from './restDatasource';
import { User } from './user.model';
import { Group } from './group.model';
import { BehaviorSubject, Observable, tap, map } from 'rxjs';
import { Expense } from './expense.model';

@Injectable()
export class GroupRepositroy {
  private usersData: User[] = [];
  public groupSubject = new BehaviorSubject<any>(null);
  private groupsData$ = new BehaviorSubject<Group[]>([]);
  private expensesData: { [groupId: string]: Expense[] } = {};
  private expensesSubjects: { [groupId: string]: BehaviorSubject<Expense[]> } =
    {};
  private groupData: Group[] = [];

  constructor(private res: RestDataSource) {
    this.res.getUsers().subscribe((data) => (this.usersData = data));
    this.res.getGroups().subscribe((data) => (this.groupData = data));
    this.loadGroups().subscribe();
  }

  get groups$(): Observable<Group[]> {
    return this.groupsData$.asObservable();
  }

  loadGroups(): Observable<Group[]> {
    return this.res
      .getGroups()
      .pipe(tap((groups) => this.groupsData$.next(groups)));
  }

  addGroup(group: Group): Observable<Group> {
    const current = this.groupsData$.getValue();
    const lastGroup = current[current.length - 1];
    const lastId = lastGroup ? parseInt(lastGroup.group_id || '100', 10) : 100;

    group.group_id = (lastId + 1).toString();
    group.id = group.group_id;

    return this.res.addGroup(group).pipe(
      tap((newGroup) => {
        this.groupsData$.next([...current, newGroup]);
      })
    );
  }

  getGroups(): Observable<Group[]> {
    return this.res.getGroups();
  }

  getGroup(groupId?: string): Group | undefined {
    return this.groupsData$.getValue().find((g) => g.group_id == groupId);
  }

  getUser(userId: string) {
    return this.usersData.find((u) => u.user_id == userId);
  }

  getGroupUsersData(groupId?: string): User[] {
    const group = this.getGroup(groupId);
    if (!group || !group.members) return [];
    return group.members
      .map((uid) => this.usersData.find((u) => u.user_id === uid))
      .filter((u): u is User => !!u);
  }

  getGroupExpenses(groupId: string) {
    return this.res.getExpensesByGroup(Number(groupId));
  }

  updateGroup(groupId: string, updatedGroup: Group): Observable<Group> {
    return this.res.updateGroup(groupId, updatedGroup).pipe(
      tap((updated) => {
        const list = this.groupsData$.getValue();
        const idx = list.findIndex((g) => (g.group_id ?? g.id) === groupId);
        if (idx >= 0) {
          const next = list.slice();
          next[idx] = updated;
          this.groupsData$.next(next);
          this.groupSubject.next(updated);
        } else {
          this.groupsData$.next([...list, updated]);
          this.groupSubject.next(updated);
        }
      })
    );
  }

  addMembersToGroup(userIds: string[], groupId?: string): Observable<Group> {
    const group = this.getGroup(groupId);
    const existing = new Set(group?.members ?? []);
    const merged = [...existing, ...userIds].map((x) => x);

    const updatedGroup: Group = {
      ...(group ?? ({ group_id: groupId } as Group)),
      id: group?.id ?? groupId,
      members: merged,
      group_name: group?.group_name,
      description: group?.description,
      category: group?.category,
      created_by: group?.created_by,
      expenses: group?.expenses ?? [],
    };

    if (groupId) {
      return this.updateGroup(groupId, updatedGroup);
    } else {
      console.log('group undefined');
      return new Observable<Group>();
    }
  }

  getAdminGroups(): Group[] {
    return this.groupData;
  }

  deleteByAdminGroup(group: Group): void {
    console.log(group.group_id);
    this.res.deleteGroupByAdmin(group.group_id).subscribe(() => {
      this.groupData = this.groupData.filter(
        (o) => o.group_id !== group.group_id
      );
    });
  }

  deleteGroup(group: Group): void {
    console.log(group.group_id);
    this.res.deleteGroup(group.group_id).subscribe(() => {
      const updatedGroups = this.groupsData$
        .getValue()
        .filter((o) => o.group_id !== group.group_id);

      this.groupsData$.next(updatedGroups);
    });
  }

  getExpenses$(groupId?: string): Observable<Expense[]> {
    if (groupId) {
      if (!this.expensesSubjects[groupId]) {
        this.expensesSubjects[groupId] = new BehaviorSubject<Expense[]>([]);
        this.refreshExpenses(groupId).subscribe();
      }
      return this.expensesSubjects[groupId].asObservable();
    } else {
      console.log('group undefined');
      return new Observable<Expense[]>();
    }
  }

  refreshExpenses(groupId: string): Observable<Expense[]> {
    return this.res.getExpensesByGroup(Number(groupId)).pipe(
      tap((expenses) => {
        this.expensesData[groupId] = expenses;
        if (this.expensesSubjects[groupId]) {
          this.expensesSubjects[groupId].next(expenses);
        }
      })
    );
  }

  addExpense(expense: Expense): Observable<Expense> {
    if (!expense.id) {
      expense.id = Date.now().toString();
    }

    return this.res.addExpense(expense).pipe(
      tap((created) => {
        const gid = created.group_id!;
        if (!this.expensesData[gid]) this.expensesData[gid] = [];
        this.expensesData[gid].push(created);
        if (this.expensesSubjects[gid]) {
          this.expensesSubjects[gid].next([...this.expensesData[gid]]);
        }
      })
    );
  }
}
